import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'app_config.dart';

/// Default [FirebaseOptions] for SAKTI mobile and web.
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    String apiKey = _val(
      AppConfig.firebaseApiKey,
      'AIzaSyC3ur1v5pBVCoQ5rjFvedt-4phJYIPCfxs',
    );
    String appId = _val(
      AppConfig.firebaseAppId,
      '1:87970207964:web:cbbf8d26010cf507dbbc19',
    );

    if (!kIsWeb) {
      if (defaultTargetPlatform == TargetPlatform.android) {
        // Android API Key & App ID from google-services.json
        apiKey = 'AIzaSyDQ-BevdVWlVltQ70YI1fZRhR-mp3uDucA';
        final androidId = _val(
          AppConfig.firebaseAndroidAppId,
          '1:87970207964:android:010e832378174ab5dbbc19',
        );
        if (androidId.isNotEmpty) appId = androidId;
      } else if (defaultTargetPlatform == TargetPlatform.iOS) {
        final iosId = _val(AppConfig.firebaseIosAppId, '');
        if (iosId.isNotEmpty) appId = iosId;
      }
    }

    return FirebaseOptions(
      apiKey: apiKey,
      appId: appId,
      messagingSenderId: _val(AppConfig.firebaseSenderId, '87970207964'),
      projectId: _val(AppConfig.firebaseProjectId, 'sakti-schemes'),
      authDomain: _val(
        AppConfig.firebaseAuthDomain,
        'sakti-schemes.firebaseapp.com',
      ),
      storageBucket: _val(
        AppConfig.firebaseStorageBucket,
        'sakti-schemes.firebasestorage.app',
      ),
      measurementId: _val(AppConfig.firebaseMeasurementId, 'G-W0N3FSSXH3'),
    );
  }

  /// Helper to return AppConfig value if valid, or project fallback if it's empty or placeholder
  static String _val(String configValue, String fallback) {
    if (configValue.isNotEmpty && !configValue.toLowerCase().contains('your')) {
      return configValue;
    }
    return fallback;
  }
}
